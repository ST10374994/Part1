/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part1;

import static part1.Part1.taskCounter;

public class Task {
    private String taskDescription;
    private String status;
    private int hours; // Assuming each task has an associated hours attribute
    private static int totalHours = 0; // Static variable to store total combined hours of all tasks

    public Task(String description, int hours) {
        this.taskDescription = description;
        this.hours = hours;
        this.status = "To Do"; // Set initial status to "To Do"
        totalHours += hours; // Add hours of this task to the total
    }

    public boolean checkTaskDescription() {
        return taskDescription != null && taskDescription.length() <= 50;
    }

    public String createTaskID(String developerName) {
        String[] words = taskDescription.split("\\s+"); // Split task description into words
        String firstTwoLetters = "";
        String lastThreeLetters = "";

        // Get the first two letters of the first word (or the whole word if it's less than 2 letters)
        if (words.length > 0) {
            firstTwoLetters = words[0].substring(0, Math.min(2, words[0].length()));
        }

        // Get the last three letters of the developer's name (or the whole name if it's less than 3 letters)
        if (developerName.length() >= 3) {
            lastThreeLetters = developerName.substring(developerName.length() - 3).toUpperCase();
        } else {
            lastThreeLetters = developerName.toUpperCase();
        }

        // Generate and return the task ID
        return firstTwoLetters.toUpperCase() + ":" + taskCounter++ + ":" + lastThreeLetters;
    }

    public String printTaskDetails() {
        return "Task Description: " + taskDescription + "\nStatus: " + status;
    }

    public int returnTotalHours() {
        return totalHours;
    }

    // Getters and setters
    public String getDescription() {
        return taskDescription;
    }

    public void setDescription(String description) {
        this.taskDescription = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        totalHours -= this.hours; // Subtract the current hours from total
        totalHours += hours; // Add the new hours to total
        this.hours = hours;
    }
}