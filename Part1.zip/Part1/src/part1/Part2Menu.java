/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part1;

public class Part2Menu {
    public static void showMenu() {
        System.out.println("Here your Option:");
        System.out.println("1. Add Task");
        System.out.println("2. Show Report");
        System.out.println("3. Quit");
        System.out.println("Please choose one if this option:");
    }
}
