
package part1;

public class Login {
    // Method to login a user with the provided username and password
    public static boolean loginUser(String username, String password) {
        return password.equals(Part1.regPassword) && username.equals(Part1.regUsername);
    }

    // Method to return the login status message
    public static String returnLoginStatus(boolean loginUser, String firstName, String lastName) {
        if (loginUser) {
            return "A successful login.";
        } else {
            return "A failed login";
        }
    }
}