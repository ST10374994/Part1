package part1;

import javax.swing.JOptionPane;

public class Part1 {
    static String regUsername = null;
    static String regPassword = null;
    static int taskCounter = 0; // Counter for task numbering

    public static void main(String[] args) {
        String userName;
        String password;
        String firstName;
        String lastName;

        boolean registrationSuccessful = false; // Flag to track registration success

        JOptionPane.showMessageDialog(null, "Welcome to Registration!");

        regUsername = JOptionPane.showInputDialog(null, "Please register your username:");
        boolean isUsernameValid = Registration.checkUserName(regUsername);
        if (!isUsernameValid) {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return;
        }
        JOptionPane.showMessageDialog(null, "Username successfully captured");

        regPassword = JOptionPane.showInputDialog(null, "Please Register your password:");
        boolean isPasswordValid = Registration.checkPasswordComplexity(regPassword);
        if (!isPasswordValid) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return;
        }
        JOptionPane.showMessageDialog(null, "Password successfully captured");

        String regResult = Registration.registerUser(regUsername, regPassword);
        if (regResult.equals("Registration successful")) {
            registrationSuccessful = true; // Set flag to true
        } else {
            JOptionPane.showMessageDialog(null, regResult); // Print registration failure message
            return;
        }

        if (registrationSuccessful) {
            JOptionPane.showMessageDialog(null, "Registration was successful. Please proceed to login.");

            userName = JOptionPane.showInputDialog(null, "Please enter Login username.");
            if (!userName.equals(regUsername)) {
                JOptionPane.showMessageDialog(null, "Incorrect username. Please enter the correct username.");
                return;
            }

            password = JOptionPane.showInputDialog(null, "Please enter Login password.");
            if (!password.equals(regPassword)) {
                JOptionPane.showMessageDialog(null, "Incorrect password. Please enter the correct password.");
                return;
            }

            JOptionPane.showMessageDialog(null, "A successful login.");

            firstName = JOptionPane.showInputDialog(null, "Please enter your first name");
            lastName = JOptionPane.showInputDialog(null, "Please enter your last name");

            JOptionPane.showMessageDialog(null, "A successful login. Welcome " + firstName + " " + lastName + ", it is great to see you again.");

            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

            // Start Task Feature
            taskFeature();
        }
    }

    static void taskFeature() {
        while (true) {
            JOptionPane.showMessageDialog(null, "Hello, welcome to our Task Feature. Please choose one of our 3 options:");
            String[] options = {"Add Task", "Show Report", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]); // Show menu options
            switch (choice) {
                case 0 -> addTask();
                case 1 -> JOptionPane.showMessageDialog(null, "Option 2: Show Report - Coming Soon");
                case 2 -> {
                    JOptionPane.showMessageDialog(null, "Option 3: Quit!");
                    return;
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
            }
        }
    }

    static void addTask() {
        JOptionPane.showMessageDialog(null, "Option 1: Add Task");
        String taskName = JOptionPane.showInputDialog(null, "Please enter the task name:");
        if (taskName != null && taskName.length() <= 50) {
            JOptionPane.showMessageDialog(null, "Task " + taskCounter++ + ": " + taskName + " added."); // Increment the counter and display task name with number
            // Here you can perform any additional processing with the task name
        } else {
            JOptionPane.showMessageDialog(null, regUsername + " you have exceeded the maximum amount.");
        }
    }
}