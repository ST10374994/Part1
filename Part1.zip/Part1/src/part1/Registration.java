package part1;

public class Registration {
    // Method to check if the username is correctly formatted
    public static boolean checkUserName(String userName) {
        // Check if username is not null and contains an underscore
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }

    // Method to check if the password meets complexity requirements
    public static boolean checkPasswordComplexity(String password) {
        // Password complexity rules:
        // - At least 8 characters long
        // - Contains at least one uppercase letter
        // - Contains at least one lowercase letter
        // - Contains at least one digit (0-9)
        // - Contains at least one special character
        String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
        return password.matches(regex);
    }

    // Method to register a user with the provided username and password
    public static String registerUser(String username, String password) {
        // Implementation for user registration
        return "Registration successful"; // For demonstration purposes
    }
}